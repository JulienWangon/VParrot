<?php

define("BASE_PATH", "api.garage-vparrot.j-webflow.com/");